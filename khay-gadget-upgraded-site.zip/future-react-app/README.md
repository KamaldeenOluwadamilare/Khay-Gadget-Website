
# Future React Integration (Khay Gadget)

This folder is reserved for future upgrade to a React or Vue-based single-page application.
You can build from here using:
- Vite + React + Tailwind
- Vue 3 + Pinia + Vite
- SvelteKit, etc.

Use this folder to scaffold your app when you're ready.

🔥 Start command:
npx create-vite-app . --template react

